// src/components/Pagination.js

import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setPage } from '../store/slices/newsSlice';

const Pagination = () => {
  const dispatch = useDispatch();
  const { page } = useSelector((state) => state.news);

  const handlePrevPage = () => {
    if (page > 1) {
      dispatch(setPage(page - 1));
    }
  };

  const handleNextPage = () => {
    dispatch(setPage(page + 1));
  };

  return (
    <div className="d-flex justify-content-center my-4">
      <button className="btn btn-primary mx-2" onClick={handlePrevPage} disabled={page === 1}>
        Previous
      </button>
      <button className="btn btn-primary mx-2" onClick={handleNextPage}>
        Next
      </button>
    </div>
  );
};

export default Pagination;
