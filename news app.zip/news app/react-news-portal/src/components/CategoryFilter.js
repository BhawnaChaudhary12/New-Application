// src/components/CategoryFilter.js

import React from 'react';
import { useDispatch } from 'react-redux';
import { setCategory, setPage } from '../store/slices/newsSlice';

const CategoryFilter = () => {
  const dispatch = useDispatch();

  const handleCategoryChange = (event) => {
    dispatch(setCategory(event.target.value));
    dispatch(setPage(1));
  };

  return (
    <div className="mb-4">
      <select className="form-select" onChange={handleCategoryChange}>
        <option value="general">General</option>
        <option value="business">Business</option>
        <option value="technology">Technology</option>
        <option value="entertainment">Entertainment</option>
      </select>
    </div>
  );
};

export default CategoryFilter;
