// src/components/Header.js

import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (

      
    <header className="bg-primary text-white text-center py-3">
      <h1>News Portal</h1>
      <nav>
        <Link to="/" className="text-white mx-2">Home</Link>
      </nav>
      
    </header>
    
  );
};

export default Header;
