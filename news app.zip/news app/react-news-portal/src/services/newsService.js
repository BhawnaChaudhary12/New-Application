// src/services/newsService.js

import axios from 'axios';

const API_KEY = 'fe20a32868d545309051284e1f46dec2';
const BASE_URL = 'https://newsapi.org/v2';

export const fetchNews = async (category = 'general', page = 1) => {
  try {
    const response = await axios.get(`${BASE_URL}/top-headlines`, {
      params: {
        category,
        page,
        apiKey: API_KEY,
        country: 'in',
      },
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};
